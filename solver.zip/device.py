"""
This module represents a device.

Computer Systems Architecture Course
Assignment 1
March 2019
"""
from Queue import Queue
from threading import Event, Thread, Lock, RLock
from reusable_barrier_semaphore import ReusableBarrier



class Device(object):
    """
    Class that represents a device.
    """

    def __init__(self, device_id, sensor_data, supervisor):
        """
        Constructor.

        @type device_id: Integer
        @param device_id: the unique id of this node; between 0 and N-1

        @type sensor_data: List of (Integer, Float)
        @param sensor_data: a list containing (location, data) as measured by this device

        @type supervisor: Supervisor
        @param supervisor: the testing infrastructure's control and validation component
        """
        self.device_id = device_id
        self.sensor_data = sensor_data
        self.supervisor = supervisor
        self.scripts = []
        self.timepoint_done = Event()
        self.thread = DeviceThread(self)
        self.thread.start()

        self.devices = None
        self.devices_barrier = None
        self.last_id_processed = -1
        self.scripts_lock = Lock()
        self.locks_location = []
        self.max_locations = 100

        #create an array with dimension self.max_locations initialized at NULL
        for _ in range(0, self.max_locations):
            self.locks_location.append(None)


    def __str__(self):
        """
        Pretty prints this device.

        @rtype: String
        @return: a string containing the id of this device
        """
        return "Device %d" % self.device_id

    def setup_devices(self, devices):
        """
        Setup the devices before simulation begins.

        @type devices: List of Device
        @param devices: list containing all devices
        """
        self.devices = devices
        if self.device_id == 0:
            #create and share a unique Rbarrier for each device
            devices_barrier = ReusableBarrier(len(devices))
            for i in range(0, len(self.devices)):
                devices[i].devices_barrier = devices_barrier
            #create and share an RLock() for each possible location between devices
            for i in range(0, self.max_locations):
                lock_location_i = RLock()
                for j in range(0, len(self.devices)):
                    self.devices[j].locks_location[i] = lock_location_i



    def assign_script(self, script, location):
        """
        Provide a script for the device to execute.

        @type script: Script
        @param script: the script to execute from now on at each timepoint; None if the
            current timepoint has ended

        @type location: Integer
        @param location: the location for which the script is interested in
        """
        if script is not None:
            self.scripts_lock.acquire()

            self.scripts.append((script, location))

            self.scripts_lock.release()

        else:
            self.timepoint_done.set()

    def get_data(self, location):
        """
        Returns the pollution value this device has for the given location.

        @type location: Integer
        @param location: a location for which obtain the data

        @rtype: Float
        @return: the pollution value
        """
        self.locks_location[location].acquire()

        res = self.sensor_data[location] if location in self.sensor_data else None

        self.locks_location[location].release()

        return res

    def set_data(self, location, data):
        """
        Sets the pollution value stored by this device for the given location.

        @type location: Integer
        @param location: a location for which to set the data

        @type data: Float
        @param data: the pollution value
        """
        self.locks_location[location].acquire()

        if location in self.sensor_data:
            self.sensor_data[location] = data

        self.locks_location[location].release()

    def shutdown(self):
        """
        Instructs the device to shutdown (terminate all threads). This method
        is invoked by the tester. This method must block until all the threads
        started by this device terminate.
        """
        self.thread.join()


class MultipleThread(Thread):
    """
    Class that represents one of the threads of each device (8)
    """

    def __init__(self, device, queue, barrier):
        """
        Returns the pollution value this device has for the given location.

        @type device: Device
        @param device: the device owner

        @type queue: Queue
        @param queue: queue of threads common for each MultipleThreads of the same device

        @type barrier: ReusableBarrier
        @param barrier: barrier to synch each MultipleThread at each timepoint
        """
        Thread.__init__(self)
        self.device = device
        self.queue_threads = queue
        self.multiple_threads_barrier = barrier

    def run(self):
        while True:
            (neighbours, script, location) = self.queue_threads.get()
            #if neighbours were None,close the thread and join the parent(DeviceThread)
            if location == -2:
                break
            #if the last script received by parent(DeviceThread) was None close the thread
            #wait for all other correlated MultipleThreads to come using barrier
            elif location == -1:
                self.multiple_threads_barrier.wait()
                continue
            #else collect and process data from neighbours
            #but not before locking current location
            else:
                self.device.locks_location[location].acquire()
                script_data = []
                # collect data from current neighbours
                for device in neighbours:
                    data = device.get_data(location)
                    if data is not None:
                        script_data.append(data)
                # add our data, if any
                data = self.device.get_data(location)
                if data is not None:
                    script_data.append(data)

                if script_data != []:
                    # run script on data
                    result = script.run(script_data)

                # update data of neighbours, hope no one is updating at the same time
                    for device in neighbours:
                        device.set_data(location, result)
                # update our data, hope no one is updating at the same time
                    self.device.set_data(location, result)
                #unlock current location
                self.device.locks_location[location].release()





class DeviceThread(Thread):
    """
    Class that implements the device's worker thread.
    """
    def __init__(self, device):
        """
        Constructor.

        @type device: Device
        @param device: the device which owns this thread
        """
        Thread.__init__(self, name="Device Thread %d" % device.device_id)
        self.device = device
        self.threads_list = []
        #queue for each 8 MultipleThreads per device
        self.queue_threads = Queue()
        self.no_threads = 8


    def run(self):
        #create and share a barrier between each 8 MultipleThreads per device
        multiple_threads_barrier = ReusableBarrier(self.no_threads)
        for i in range(0, self.no_threads):
            thread = MultipleThread(self.device, self.queue_threads, multiple_threads_barrier)
            self.threads_list.append(thread)
            #start each MultipleThread
            self.threads_list[i].start()

        while True:
            # get the current neighbourhood
            neighbours = self.device.supervisor.get_neighbours()
            if neighbours is None:
                #send no_threads * signal to announce exit
                for i in range(0, self.no_threads):
                    self.queue_threads.put((None, None, -2))
                #swait for threads to join() before exiting
                for i in range(0, self.no_threads):
                    self.threads_list[i].join()
                break

            while True:
                #lock for scripts_list
                self.device.scripts_lock.acquire()
                #if last script added from queue and the flag for timepoint is True
                # send no_threads * signal to unlock blocked MultipleThreads
                if self.device.last_id_processed == len(self.device.scripts) - 1:
                    if self.device.timepoint_done.isSet() is True:
                        for i in range(0, self.no_threads):
                            #signal for None
                            self.queue_threads.put((None, None, -1))

                        self.device.scripts_lock.release()
                        break
                #if last script added is the same as the last script from scripts_list
                # do nothing
                if self.device.last_id_processed == len(self.device.scripts) - 1:
                    self.device.scripts_lock.release()
                    continue
                #else, add (neighbours,script,location) to the queue and increment
                # last_id_processed
                self.device.last_id_processed = self.device.last_id_processed + 1
                (script, location) = self.device.scripts[self.device.last_id_processed]
                self.queue_threads.put((neighbours, script, location))
                #unlock the scripts_list
                self.device.scripts_lock.release()


            self.device.timepoint_done.wait()
            #reset timepoint flag
            self.device.timepoint_done.clear()
            #reset last_id_processed to -1 for a new timepoint
            self.device.last_id_processed = -1
            #wait each device to arrive
            self.device.devices_barrier.wait()
            