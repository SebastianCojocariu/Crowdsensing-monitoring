"""
This module represents a barrier

Computer Systems Architecture Course
Assignment 1
March 2019
"""
from threading import Lock, Semaphore

class ReusableBarrier(object):
    """
    Class that represents a barrier.
    """
    def __init__(self, num_threads):
        self.num_threads = num_threads
        self.count_threads1 = [self.num_threads]
        self.count_threads2 = [self.num_threads]
        self.count_lock = Lock()                 # protejam accesarea/modificarea contoarelor
        self.threads_sem1 = Semaphore(0)         # blocam thread-urile in prima etapa
        self.threads_sem2 = Semaphore(0)         # blocam thread-urile in a doua etapa
    def wait(self):
        """
        wait method
        """
        self.phase(self.count_threads1, self.threads_sem1)
        self.phase(self.count_threads2, self.threads_sem2)
    def phase(self, count_threads, threads_sem):
        """
        Setup the devices before simulation begins.

        @type count_threads: Integer
        @param count_threads: number of threads

        @type threads_sem: Semaphore
        @param threads_sem: Semaphore
        """
        with self.count_lock:
            count_threads[0] -= 1
            # a ajuns la bariera si ultimul thread
            if count_threads[0] == 0:
                for _ in range(self.num_threads):
                    # incrementarea semaforului va debloca num_threads thread-uri
                    threads_sem.release()
                # reseteaza contorul
                count_threads[0] = self.num_threads
        # num_threads-1 threaduri se blocheaza aici
        threads_sem.acquire()
        # contorul semaforului se decrementeaza de num_threads ori
